CECSATSolver

CEC-SAT verification software for ISTD 2D Design Challenge

Team members:
----------------------------------------------------------------------------------------------------------
Cheong Renjie Joshua        1000077
Kang Yue Sheng Benjamin     1000069
Liza Ng Yu Shan	            1000097
Chew Guan Xun               1000037
Tan En Yi                   (needs further verification on participation due to sick leave)

Instructions:
----------------------------------------------------------------------------------------------------------
Open "src.sat.SATSolverTest.java" after adding project to your Java IDE (e.g Eclipse)

Some sample test cases download from the web are avaliable in "/test_cases"
Do note that number of clauses or literals are not representative of "difficulty" of test cases.

Test cases are verified with online javascript SAT solver at http://www.comp.nus.edu.sg/~gregory/sat/

